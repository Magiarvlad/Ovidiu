﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ovidiu.Clase
{
    public class DateSetariImplicite
    {
        public string Cod { get; set; }
        public string Denumire { get; set; }
    }
}
